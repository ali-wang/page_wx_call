<?php 
header("Content-Type:text/html;charset=utf-8");
//修改微信号码
$file_path = "wx.txt";
if(file_exists($file_path))
	{
		$str = file_get_contents($file_path);
		$str = str_replace("\r\n","<br />",$str);
	}


//修改跳转链接

	
echo 'arr_wx = ['.$str.'];
      var wx_index = Math.floor(Math.random()*arr_wx.length);
      var stxlwx = arr_wx[wx_index];
	  ';

//echo "var wx_img = \"<img style='width:100%;display:block;' src='img/\"+ stxlwx +\".jpg'>\";\n"; 




	  ?>
	  